defmodule Tightbeam.Schema do
  @moduledoc "The single production-owned schema bootstrap for a Tightbeam database."

  alias Tightbeam.DB
  alias Tightbeam.DB.Txn

  @schema_modules [
    Tightbeam.Ledger,
    Tightbeam.EventLog,
    Tightbeam.Assets,
    Tightbeam.Artifacts,
    Tightbeam.CausalEvents,
    Tightbeam.Devices,
    Tightbeam.Idempotency,
    Tightbeam.ConditionFacts,
    Tightbeam.SubagentMarkers,
    Tightbeam.Escalation,
    Tightbeam.Wakes,
    Tightbeam.NoticeBatcher,
    Tightbeam.Projection,
    Tightbeam.Org,
    Tightbeam.ColdStart,
    Tightbeam.CriticalLeases,
    Tightbeam.Roles,
    Tightbeam.ReadMarkers,
    Tightbeam.WorkItems,
    Tightbeam.Assignments,
    Tightbeam.EffortCheckin,
    Tightbeam.Placement,
    Tightbeam.RecurrenceSuppression,
    Tightbeam.RailRemedy,
    Tightbeam.Supervision,
    Tightbeam.WorkState,
    Tightbeam.Productions.BubbleSweeper,
    Tightbeam.HarnessProcess,
    Tightbeam.AdminProjection,
    Tightbeam.HarnessHealth
  ]

  # The shape this build writes. Bump it when a production table changes in a
  # way that makes an older database unreadable, and give the refusal below a
  # sentence saying what changed.
  #
  # TWO LINES CARRIED THIS PHASE TO DIFFERENT NAMES, and this stamp is where
  # they merge. Wave 1 (wakes classes/delivery, seams ①/②) stamped
  # `coordination-fabric-classes-v1` then `-v2` (`classElection` gained
  # `'batcher'`, Sol xhigh review round 2 finding 2). Wave 2 (the agent
  # question arm, seams ③/④) stamped `coordination-fabric-v1-phase1` then
  # `-v2` (`decision_requests.deadlineAt` went from `NOT NULL` to nullable,
  # Sol xhigh review round 2 finding 2 on THAT delta). Neither name ever
  # described the OTHER line's DDL, so neither could serve the merged tree —
  # this is a THIRD, brand-new name covering the union of both waves' schema
  # (`wakes`'s class/delivery columns AND `decision_requests`'s agent arm),
  # never having named any earlier vintage of either line (verified against
  # both histories at merge time).
  #
  # `decision_requests.deadlineAt` went from `NOT NULL` to nullable at
  # `coordination-fabric-v1-phase1-v2` (2026-08-13, Sol xhigh review round 2,
  # finding 2 on that delta) — the agent arm's CHECK grew an explicit
  # `deadlineAt IS NULL` requirement (finding 1 of round 1 on the same
  # delta), and the stamp bumped for the same reason wave 1's did.
  #
  # `CREATE TABLE IF NOT EXISTS` adds no column to a table that already
  # exists and does not widen an existing CHECK or relax an existing NOT
  # NULL — a `classes-v1`, `classes-v2`, `v1-phase1`, or `v1-phase1-v2`
  # database's tables still enforce their OLD shapes exactly, so the first
  # read or write this build makes against the NEW columns/constraints would
  # die on a raw, unnamed SQLite error instead of a refusal that names what
  # changed. Refuse, name it, and let the database be recreated.
  # Mike's 2026-08-22 decision-reader return ruling adds the `returned`
  # disposition and three audit columns to `decision_requests`. SQLite cannot
  # widen the existing status/arm CHECKs or add those columns through
  # `CREATE TABLE IF NOT EXISTS`, so a v3 database must refuse by name rather
  # than failing on the first return with a raw column/CHECK error.
  # The operational-parent port adds a required `sessions.operationalParent`
  # column. The v4 stamp is the one exact predecessor that upgrade accepts.
  # The nullable transcript discriminator adds `messages.messageType`; v6 is
  # its one exact predecessor, and historical rows remain null.
  # Terminal operator decisions advance v7 to v8. Nullable effective parent
  # then relaxes the stored parent constraint from that exact predecessor.
  @shape "coordination-fabric-v1-phase1-v9"
  @nullable_effective_parent_previous_shape "coordination-fabric-v1-phase1-v8"
  @terminal_decision_previous_shape "coordination-fabric-v1-phase1-v7"
  @message_type_previous_shape "coordination-fabric-v1-phase1-v6"
  @cold_start_previous_shape "coordination-fabric-v1-phase1-v5"
  @operational_parent_shape "coordination-fabric-v1-phase1-v5"
  @operational_parent_previous_shape "coordination-fabric-v1-phase1-v4"

  @supervision_liveness_objects [
    %{
      type: "table",
      name: "supervision_entitlements",
      sql: """
      CREATE TABLE IF NOT EXISTS supervision_entitlements (
        assignmentId TEXT PRIMARY KEY REFERENCES assignments(id),
        generation INTEGER NOT NULL CHECK (generation > 0),
        dueAt INTEGER,
        state TEXT NOT NULL CHECK (state IN ('armed','claimed','terminus')),
        lastAttemptGeneration INTEGER,
        claimClock INTEGER,
        basisKind TEXT NOT NULL CHECK (basisKind IN (
          'assignment_open','prod_scheduled','escalation_scheduled','policy_denied',
          'progress','no_terminal','parent_retirement','recovery_backfill'
        )),
        basisId TEXT NOT NULL,
        terminusAt INTEGER,
        cause TEXT NOT NULL CHECK (cause IN (
          'assignment_open','progress','deadline','new_terminal','pending_turn','pending_wake',
          'work_blocked','prod_scheduled','escalation_scheduled','policy_denied','no_terminal',
          'terminal_disposition','holder_retired','parent_elevated','terminus',
          'parent_target_retired','recovery_backfill','stale_generation'
        )),
        principal TEXT NOT NULL,
        supervisionIntervalMs INTEGER,
        CHECK (
          (state = 'armed' AND dueAt >= 0 AND supervisionIntervalMs > 0 AND
           claimClock IS NULL AND terminusAt IS NULL)
          OR
          (state = 'claimed' AND dueAt >= 0 AND supervisionIntervalMs > 0 AND
           claimClock >= 0 AND terminusAt IS NULL)
          OR
          (state = 'terminus' AND dueAt IS NULL AND supervisionIntervalMs IS NULL AND
           claimClock IS NULL AND lastAttemptGeneration IS NULL AND terminusAt >= 0)
        ),
        CHECK (
          lastAttemptGeneration IS NULL OR
          (lastAttemptGeneration > 0 AND lastAttemptGeneration <= generation)
        )
      )
      """
    },
    %{
      type: "table",
      name: "supervision_progress_absorptions",
      sql: """
      CREATE TABLE IF NOT EXISTS supervision_progress_absorptions (
        attestId TEXT PRIMARY KEY REFERENCES attests(id),
        assignmentId TEXT NOT NULL REFERENCES assignments(id),
        attestTs INTEGER NOT NULL CHECK (attestTs >= 0),
        generation INTEGER NOT NULL CHECK (generation > 0),
        recoveryBaseline INTEGER NOT NULL CHECK (recoveryBaseline IN (0,1)),
        cause TEXT NOT NULL CHECK (cause IN ('progress','recovery_backfill')),
        principal TEXT NOT NULL,
        CHECK (
          (recoveryBaseline = 0 AND cause = 'progress') OR
          (recoveryBaseline = 1 AND cause = 'recovery_backfill' AND
           principal = 'process:tightbeam')
        )
      )
      """
    },
    %{
      type: "table",
      name: "supervision_liveness_sidecar",
      sql: """
      CREATE TABLE IF NOT EXISTS supervision_liveness_sidecar (
        wakeId TEXT PRIMARY KEY REFERENCES wakes(wakeId),
        assignmentId TEXT NOT NULL REFERENCES assignments(id),
        controllerOrigin TEXT CHECK (controllerOrigin IN ('scheduled','retirement_elevation')),
        wakeKind TEXT CHECK (wakeKind IN ('prod','escalation')),
        controllerState TEXT CHECK (controllerState IN ('pending','settled')),
        chargedGeneration INTEGER CHECK (chargedGeneration > 0),
        transferEvidenceId TEXT,
        retirementEpoch INTEGER CHECK (retirementEpoch >= 0),
        retiringSessionKey TEXT REFERENCES sessions(sessionKey),
        retirementOutcomeKind TEXT CHECK (
          retirementOutcomeKind IN ('child_rearm','parent_elevation','main_elevation')
        ),
        retirementOutcomeId TEXT,
        retirementTargetSessionKey TEXT REFERENCES sessions(sessionKey),
        retirementCause TEXT CHECK (
          retirementCause IN ('parent_target_retired','legacy_parent_target_retired')
        ),
        retirementPrincipal TEXT,
        retirementActionNeeded INTEGER CHECK (retirementActionNeeded IN (0,1)),
        rootTurnSeq INTEGER REFERENCES turns(seq),
        CHECK (
          (controllerOrigin IS NULL AND wakeKind IS NULL AND controllerState IS NULL AND
           chargedGeneration IS NULL)
          OR
          (controllerOrigin = 'scheduled' AND wakeKind IN ('prod','escalation') AND
           controllerState IN ('pending','settled') AND chargedGeneration > 0)
          OR
          (controllerOrigin = 'retirement_elevation' AND wakeKind = 'escalation' AND
           controllerState = 'settled' AND chargedGeneration IS NULL)
        ),
        CHECK (
          (transferEvidenceId IS NULL AND retirementEpoch IS NULL AND
           retiringSessionKey IS NULL AND retirementOutcomeKind IS NULL AND
           retirementOutcomeId IS NULL AND retirementTargetSessionKey IS NULL AND
           retirementCause IS NULL AND retirementPrincipal IS NULL AND
           retirementActionNeeded IS NULL)
          OR
          (transferEvidenceId IS NOT NULL AND retirementEpoch >= 0 AND
           retiringSessionKey IS NOT NULL AND retirementOutcomeKind IS NOT NULL AND
           retirementOutcomeId IS NOT NULL AND retirementCause IS NOT NULL AND
           retirementPrincipal IS NOT NULL AND retirementActionNeeded IN (0,1) AND
           ((retirementOutcomeKind = 'child_rearm' AND
             retirementTargetSessionKey IS NULL AND retirementActionNeeded = 0)
            OR
            (retirementOutcomeKind = 'parent_elevation' AND
             retirementTargetSessionKey IS NOT NULL AND retirementActionNeeded = 0)
            OR
            (retirementOutcomeKind = 'main_elevation' AND
             retirementTargetSessionKey IS NOT NULL AND retirementActionNeeded = 1)))
        ),
        CHECK (
          retirementCause IS NULL OR retirementCause = 'parent_target_retired' OR
          (retirementCause = 'legacy_parent_target_retired' AND
           retirementOutcomeKind = 'main_elevation' AND
           retirementPrincipal = 'process:tightbeam' AND retirementActionNeeded = 1)
        ),
        CHECK (controllerOrigin IS NOT NULL OR transferEvidenceId IS NOT NULL)
      )
      """
    },
    %{
      type: "table",
      name: "wake_cancellations",
      sql: """
      CREATE TABLE IF NOT EXISTS wake_cancellations (
        wakeId TEXT PRIMARY KEY,
        wakeState TEXT NOT NULL DEFAULT 'canceled' CHECK (wakeState = 'canceled'),
        canceledAt INTEGER NOT NULL CHECK (canceledAt >= 0),
        requesterKind TEXT NOT NULL CHECK (requesterKind IN ('user','session','process')),
        requesterId TEXT NOT NULL,
        reasonKind TEXT NOT NULL CHECK (reasonKind IN (
          'requester_withdrew','superseded','obligation_disposed',
          'routing_bracket_satisfied','target_retired','production_unmatched',
          'consumer_unavailable','target_unresolvable'
        )),
        causalSourceKind TEXT NOT NULL CHECK (causalSourceKind IN (
          'verb_call','wake','progress_attest','condition_fact','assignment_transition',
          'work_item_transition','decision_request','monitor_generation','routing_bracket',
          'session_transition','scheduler_delivery'
        )),
        causalSourceId TEXT NOT NULL,
        outcomeKind TEXT NOT NULL CHECK (
          outcomeKind IN ('replacement','disposition','no_replacement')
        ),
        replacementWakeId TEXT REFERENCES wakes(wakeId) DEFERRABLE INITIALLY DEFERRED,
        dispositionKind TEXT CHECK (dispositionKind IN (
          'assignment_transition','work_item_transition',
          'decision_request_transition','monitor_generation_transition'
        )),
        dispositionId TEXT,
        primaryWorkKind TEXT CHECK (primaryWorkKind IN ('assignment','work_item')),
        primaryWorkId TEXT,
        workImpactKind TEXT NOT NULL CHECK (
          workImpactKind IN ('no_linked_work','linked_work_not_open','linked_work_open')
        ),
        livenessTriggerKind TEXT CHECK (livenessTriggerKind IN (
          'supervision_entitlement','supervision_transfer','pending_wake','routing_bracket'
        )),
        livenessTriggerId TEXT,
        actionNeeded INTEGER NOT NULL CHECK (actionNeeded IN (0,1)),
        FOREIGN KEY (wakeId, wakeState, canceledAt)
          REFERENCES wakes(wakeId, state, canceledAt) DEFERRABLE INITIALLY DEFERRED,
        CHECK (
          (workImpactKind = 'no_linked_work' AND primaryWorkKind IS NULL AND
           primaryWorkId IS NULL)
          OR
          (workImpactKind IN ('linked_work_not_open','linked_work_open') AND
           primaryWorkKind IS NOT NULL AND primaryWorkId IS NOT NULL)
        ),
        CHECK (
          (outcomeKind = 'replacement' AND replacementWakeId IS NOT NULL AND
           replacementWakeId != wakeId AND dispositionKind IS NULL AND dispositionId IS NULL AND
           livenessTriggerKind IS NULL AND livenessTriggerId IS NULL AND actionNeeded = 0 AND
           workImpactKind != 'linked_work_not_open')
          OR
          (outcomeKind = 'disposition' AND replacementWakeId IS NULL AND
           dispositionKind IS NOT NULL AND dispositionId IS NOT NULL AND
           ((workImpactKind = 'linked_work_open' AND livenessTriggerKind IS NOT NULL AND
             livenessTriggerId IS NOT NULL AND actionNeeded = 1)
            OR
            (workImpactKind != 'linked_work_open' AND livenessTriggerKind IS NULL AND
             livenessTriggerId IS NULL AND actionNeeded = 0)))
          OR
          (outcomeKind = 'no_replacement' AND replacementWakeId IS NULL AND
           dispositionKind IS NULL AND dispositionId IS NULL AND
           ((workImpactKind = 'linked_work_open' AND livenessTriggerKind IS NOT NULL AND
             livenessTriggerId IS NOT NULL AND actionNeeded = 1)
            OR
            (workImpactKind != 'linked_work_open' AND livenessTriggerKind IS NULL AND
             livenessTriggerId IS NULL AND actionNeeded = 0)))
        ),
        CHECK (
          (reasonKind = 'requester_withdrew' AND causalSourceKind = 'verb_call' AND
           outcomeKind = 'no_replacement')
          OR
          (requesterKind = 'process' AND (
            (requesterId = 'tightbeam:wake-scheduler' AND
             ((reasonKind = 'production_unmatched' AND causalSourceKind = 'condition_fact' AND
               outcomeKind = 'no_replacement')
              OR
              (reasonKind IN ('consumer_unavailable','target_unresolvable') AND
               causalSourceKind = 'scheduler_delivery' AND outcomeKind = 'no_replacement')))
            OR
            (requesterId = 'tightbeam:work-items' AND
             reasonKind = 'routing_bracket_satisfied' AND
             causalSourceKind IN ('assignment_transition','work_item_transition','routing_bracket') AND
             outcomeKind IN ('replacement','disposition'))
            OR
            (requesterId = 'tightbeam:assignments' AND
             reasonKind = 'obligation_disposed' AND causalSourceKind = 'assignment_transition' AND
             outcomeKind = 'disposition')
            OR
            (requesterId = 'tightbeam:effort-checkin' AND
             ((reasonKind = 'superseded' AND
               causalSourceKind IN ('wake','monitor_generation','decision_request') AND
               outcomeKind = 'replacement')
              OR
              (reasonKind = 'obligation_disposed' AND
               causalSourceKind IN ('work_item_transition','decision_request','monitor_generation') AND
               outcomeKind = 'disposition')))
            OR
            (requesterId = 'tightbeam:supervision' AND reasonKind = 'superseded' AND
             causalSourceKind = 'progress_attest' AND outcomeKind = 'no_replacement')
            OR
            -- The batcher (coordination-fabric-v1 §5). ONE shape and no other:
            -- a digest member superseded by the wake that carries it, named as
            -- its replacement. It cannot withdraw, dispose, or retire anyone's
            -- mail, and it cannot consume a member without naming where the
            -- payload went — which is what makes the digest-member audit
            -- (§11 acceptance 2) total rather than best-effort.
            (requesterId = 'tightbeam:batcher' AND reasonKind = 'superseded' AND
             causalSourceKind = 'wake' AND outcomeKind = 'replacement')
            OR
            (requesterId = 'tightbeam:retirement' AND
             ((reasonKind = 'target_retired' AND causalSourceKind = 'session_transition' AND
               outcomeKind IN ('replacement','no_replacement'))
              OR
              (reasonKind = 'obligation_disposed' AND
               causalSourceKind = 'assignment_transition' AND outcomeKind = 'disposition')))
          ))
        )
      )
      """
    },
    %{
      type: "table",
      name: "supervision_liveness_epoch",
      sql: """
      CREATE TABLE IF NOT EXISTS supervision_liveness_epoch (
        id INTEGER PRIMARY KEY CHECK (id = 0),
        activatedAt INTEGER NOT NULL CHECK (activatedAt >= 0),
        cause TEXT NOT NULL CHECK (cause = 'schema_activation'),
        principal TEXT NOT NULL CHECK (principal = 'process:tightbeam')
      )
      """
    },
    %{
      type: "index",
      name: "supervision_progress_assignment",
      sql:
        "CREATE INDEX IF NOT EXISTS supervision_progress_assignment ON supervision_progress_absorptions(assignmentId, attestTs, attestId)"
    },
    %{
      type: "index",
      name: "supervision_liveness_assignment",
      sql:
        "CREATE INDEX IF NOT EXISTS supervision_liveness_assignment ON supervision_liveness_sidecar(assignmentId, wakeId)"
    },
    %{
      type: "index",
      name: "supervision_liveness_pending_controller",
      sql:
        "CREATE UNIQUE INDEX IF NOT EXISTS supervision_liveness_pending_controller ON supervision_liveness_sidecar(assignmentId) WHERE controllerState = 'pending'"
    },
    %{
      type: "index",
      name: "supervision_liveness_retirement_dedupe",
      sql:
        "CREATE UNIQUE INDEX IF NOT EXISTS supervision_liveness_retirement_dedupe ON supervision_liveness_sidecar(transferEvidenceId, retirementEpoch, retirementCause) WHERE transferEvidenceId IS NOT NULL"
    },
    %{
      type: "index",
      name: "wakes_cancellation_state",
      sql:
        "CREATE UNIQUE INDEX IF NOT EXISTS wakes_cancellation_state ON wakes(wakeId, state, canceledAt)"
    },
    %{
      type: "trigger",
      name: "wake_cancellations_pending_insert",
      sql: """
      CREATE TRIGGER IF NOT EXISTS wake_cancellations_pending_insert
      BEFORE INSERT ON wake_cancellations
      WHEN NOT EXISTS (
        SELECT 1 FROM wakes
        WHERE wakeId = NEW.wakeId AND state = 'pending' AND canceledAt IS NULL
      )
      BEGIN
        SELECT RAISE(ABORT, 'wake cancellation carrier requires a pending wake');
      END
      """
    },
    %{
      type: "trigger",
      name: "wakes_typed_cancellation_required",
      sql: """
      CREATE TRIGGER IF NOT EXISTS wakes_typed_cancellation_required
      BEFORE UPDATE OF state, canceledAt ON wakes
      WHEN NEW.state = 'canceled' AND OLD.state != 'canceled' AND NOT EXISTS (
        SELECT 1 FROM wake_cancellations c
        WHERE c.wakeId = NEW.wakeId AND c.wakeState = NEW.state AND
          c.canceledAt = NEW.canceledAt
      )
      BEGIN
        SELECT RAISE(ABORT, 'pending wake cancellation requires typed provenance');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_liveness_retirement_immutable_update",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_liveness_retirement_immutable_update
      BEFORE UPDATE ON supervision_liveness_sidecar
      WHEN OLD.transferEvidenceId IS NOT NULL
      BEGIN
        SELECT RAISE(ABORT, 'supervision retirement outcome is immutable');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_liveness_retirement_immutable_delete",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_liveness_retirement_immutable_delete
      BEFORE DELETE ON supervision_liveness_sidecar
      WHEN OLD.transferEvidenceId IS NOT NULL
      BEGIN
        SELECT RAISE(ABORT, 'supervision retirement outcome is immutable');
      END
      """
    }
  ]

  # Added after the v1 activation shipped, so this cannot join the all-or-none
  # activation list above: existing v1 databases legitimately have every base
  # object and not this trigger. It is still owned and shape-validated, and is
  # installed in the same schema transaction on the next boot.
  @supervision_liveness_enforcement_objects [
    %{
      type: "table",
      name: "supervision_liveness_receipt_state",
      sql: """
      CREATE TABLE IF NOT EXISTS supervision_liveness_receipt_state (
        assignmentId TEXT PRIMARY KEY REFERENCES assignments(id),
        artifactCursor INTEGER NOT NULL CHECK (artifactCursor >= 0),
        attestCursor INTEGER NOT NULL CHECK (attestCursor >= 0),
        workItemEventCursor INTEGER NOT NULL CHECK (workItemEventCursor >= 0),
        wakeCursor INTEGER NOT NULL CHECK (wakeCursor >= 0),
        baselineCause TEXT NOT NULL CHECK (baselineCause IN (
          'assignment_open','first_prod','recovery_backfill'
        )),
        baselinePrincipal TEXT NOT NULL
      )
      """
    },
    %{
      type: "table",
      name: "supervision_liveness_receipts",
      sql: """
      CREATE TABLE IF NOT EXISTS supervision_liveness_receipts (
        receiptId INTEGER PRIMARY KEY AUTOINCREMENT,
        assignmentId TEXT NOT NULL REFERENCES assignments(id),
        sourceKind TEXT NOT NULL CHECK (sourceKind IN (
          'artifact','work_item_update','verdict','checkpoint'
        )),
        sourceId TEXT NOT NULL,
        sourceAt INTEGER NOT NULL CHECK (sourceAt >= 0),
        acceptedAt INTEGER NOT NULL CHECK (acceptedAt >= 0),
        generation INTEGER NOT NULL CHECK (generation > 0),
        expiresAt INTEGER CHECK (expiresAt >= 0),
        UNIQUE (assignmentId, sourceKind, sourceId),
        CHECK (
          (sourceKind = 'checkpoint' AND expiresAt > acceptedAt)
          OR
          (sourceKind != 'checkpoint' AND expiresAt IS NULL)
        )
      )
      """
    },
    %{
      type: "index",
      name: "supervision_liveness_receipts_assignment",
      sql:
        "CREATE INDEX IF NOT EXISTS supervision_liveness_receipts_assignment ON supervision_liveness_receipts(assignmentId, receiptId)"
    },
    %{
      type: "table",
      name: "supervision_liveness_checkpoint_bindings",
      sql: """
      CREATE TABLE IF NOT EXISTS supervision_liveness_checkpoint_bindings (
        wakeId TEXT PRIMARY KEY REFERENCES wakes(wakeId),
        assignmentId TEXT NOT NULL REFERENCES assignments(id),
        holderSessionKey TEXT NOT NULL REFERENCES sessions(sessionKey),
        sourceTurnSeq INTEGER NOT NULL REFERENCES turns(seq),
        boundAt INTEGER NOT NULL CHECK (boundAt >= 0),
        principal TEXT NOT NULL CHECK (principal = 'process:tightbeam')
      )
      """
    },
    %{
      type: "trigger",
      name: "supervision_checkpoint_binding_insert_coherent",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_checkpoint_binding_insert_coherent
      BEFORE INSERT ON supervision_liveness_checkpoint_bindings
      WHEN NOT EXISTS (
        SELECT 1
        FROM wakes w
        JOIN assignments a ON a.id=NEW.assignmentId
        JOIN turns t ON t.seq=NEW.sourceTurnSeq
        JOIN supervision_entitlements e ON e.assignmentId=a.id
        WHERE w.wakeId=NEW.wakeId
          AND w.sessionKey=NEW.holderSessionKey
          AND w.creatorSessionKey=NEW.holderSessionKey
          AND w.consumer='prompt' AND w.state='pending'
          AND w.dueAt > w.createdAt
          AND a.holderKey=NEW.holderSessionKey AND a.state='open'
          AND t.sessionKey=NEW.holderSessionKey AND t.status='running'
          AND t.assignmentId=NEW.assignmentId
          AND e.state IN ('armed','claimed')
      )
      BEGIN
        SELECT RAISE(ABORT, 'supervision checkpoint binding requires a running held assignment');
      END
      """
    },
    %{
      type: "table",
      name: "supervision_liveness_migrations",
      sql: """
      CREATE TABLE IF NOT EXISTS supervision_liveness_migrations (
        migrationId TEXT PRIMARY KEY,
        appliedAt INTEGER NOT NULL,
        affectedRows INTEGER NOT NULL CHECK (affectedRows >= 0),
        cause TEXT NOT NULL,
        principal TEXT NOT NULL
      )
      """
    },
    %{
      type: "trigger",
      name: "supervision_liveness_sidecar_insert_coherent",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_liveness_sidecar_insert_coherent
      BEFORE INSERT ON supervision_liveness_sidecar
      WHEN NOT EXISTS (
        SELECT 1 FROM wakes w
        WHERE w.wakeId=NEW.wakeId AND w.assignmentId=NEW.assignmentId
          AND w.consumer='prompt' AND w.origin='process:tightbeam'
      )
      OR (
        NEW.controllerOrigin IS NOT NULL
        AND NOT EXISTS (
          SELECT 1 FROM wakes w
          WHERE w.wakeId=NEW.wakeId AND w.assignmentId=NEW.assignmentId
            AND w.state='pending' AND w.consumer='prompt'
            AND w.origin='process:tightbeam'
            AND (
              (NEW.wakeKind='prod' AND w.reresolve IS NULL
               AND w.reresolveSeed IS NULL AND w.reresolveRung IS NULL)
              OR
              (NEW.wakeKind='escalation' AND w.reresolve='lineage'
               AND w.reresolveSeed IS NOT NULL AND w.reresolveRung > 0)
            )
        )
      )
      OR (
        NEW.controllerOrigin='scheduled'
        AND (
          NEW.rootTurnSeq IS NULL
          OR NOT EXISTS (
            SELECT 1 FROM turns t
            WHERE t.seq=NEW.rootTurnSeq AND t.assignmentId=NEW.assignmentId
          )
        )
      )
      BEGIN
        SELECT RAISE(ABORT, 'supervision sidecar requires coherent pending wake');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_pending_controller_sidecar_update",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_pending_controller_sidecar_update
      BEFORE UPDATE ON supervision_liveness_sidecar
      WHEN OLD.controllerOrigin='scheduled' AND OLD.controllerState='pending'
        AND EXISTS (
          SELECT 1 FROM wakes w
          WHERE w.wakeId=OLD.wakeId AND w.assignmentId=OLD.assignmentId
            AND w.state='pending'
        )
        AND NOT (
          NEW.wakeId IS OLD.wakeId AND NEW.assignmentId IS OLD.assignmentId
          AND NEW.controllerOrigin IS OLD.controllerOrigin
          AND NEW.wakeKind IS OLD.wakeKind
          AND NEW.chargedGeneration IS OLD.chargedGeneration
          AND NEW.transferEvidenceId IS OLD.transferEvidenceId
          AND NEW.retirementEpoch IS OLD.retirementEpoch
          AND NEW.retiringSessionKey IS OLD.retiringSessionKey
          AND NEW.retirementOutcomeKind IS OLD.retirementOutcomeKind
          AND NEW.retirementOutcomeId IS OLD.retirementOutcomeId
          AND NEW.retirementTargetSessionKey IS OLD.retirementTargetSessionKey
          AND NEW.retirementCause IS OLD.retirementCause
          AND NEW.retirementPrincipal IS OLD.retirementPrincipal
          AND NEW.retirementActionNeeded IS OLD.retirementActionNeeded
          AND NEW.rootTurnSeq IS OLD.rootTurnSeq
          AND NEW.controllerState='settled'
        )
      BEGIN
        SELECT RAISE(ABORT, 'pending supervision controller permits settlement only');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_pending_controller_sidecar_delete",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_pending_controller_sidecar_delete
      BEFORE DELETE ON supervision_liveness_sidecar
      WHEN OLD.controllerOrigin='scheduled' AND OLD.controllerState='pending'
        AND EXISTS (
          SELECT 1 FROM wakes w
          WHERE w.wakeId=OLD.wakeId AND w.assignmentId=OLD.assignmentId
            AND w.state='pending'
        )
      BEGIN
        SELECT RAISE(ABORT, 'pending supervision controller sidecar is required');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_pending_controller_wake_identity_immutable",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_pending_controller_wake_identity_immutable
      BEFORE UPDATE OF wakeId, sessionKey, origin, consumer, assignmentId,
                       reresolve, reresolveSeed, reresolveRung
      ON wakes
      WHEN OLD.state='pending'
        AND EXISTS (
          SELECT 1 FROM supervision_liveness_sidecar s
          WHERE s.wakeId=OLD.wakeId AND s.assignmentId=OLD.assignmentId
            AND s.controllerOrigin='scheduled' AND s.controllerState='pending'
        )
        AND (
          NEW.wakeId IS NOT OLD.wakeId OR NEW.sessionKey IS NOT OLD.sessionKey
          OR NEW.origin IS NOT OLD.origin OR NEW.consumer IS NOT OLD.consumer
          OR NEW.assignmentId IS NOT OLD.assignmentId
          OR NEW.reresolve IS NOT OLD.reresolve
          OR NEW.reresolveSeed IS NOT OLD.reresolveSeed
          OR NEW.reresolveRung IS NOT OLD.reresolveRung
        )
      BEGIN
        SELECT RAISE(ABORT, 'pending supervision controller wake identity is immutable');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_lineage_fire_requires_sidecar",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_lineage_fire_requires_sidecar
      BEFORE UPDATE OF state ON wakes
      WHEN OLD.state = 'pending' AND NEW.state = 'fired'
        AND NEW.consumer = 'prompt'
        AND NEW.origin = 'process:tightbeam'
        AND NEW.assignmentId IS NOT NULL
        AND NEW.reresolve = 'lineage'
        AND (
          NOT EXISTS (
            SELECT 1 FROM supervision_liveness_sidecar s
            WHERE s.wakeId = NEW.wakeId AND s.assignmentId = NEW.assignmentId
              AND s.wakeKind = 'escalation'
              AND (
                (s.controllerOrigin = 'scheduled' AND s.controllerState = 'settled'
                 AND s.chargedGeneration > 0)
                OR
                (s.controllerOrigin = 'retirement_elevation' AND s.controllerState = 'settled'
                 AND s.chargedGeneration IS NULL)
              )
          )
          OR NOT EXISTS (
            SELECT 1 FROM turns t
            WHERE t.wakeId = NEW.wakeId AND t.assignmentId = NEW.assignmentId
          )
        )
      BEGIN
        SELECT RAISE(ABORT, 'supervision lineage wake requires controller sidecar');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_fired_lineage_sidecar_required_delete",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_fired_lineage_sidecar_required_delete
      BEFORE DELETE ON supervision_liveness_sidecar
      WHEN EXISTS (
        SELECT 1 FROM wakes w
        WHERE w.wakeId = OLD.wakeId AND w.assignmentId = OLD.assignmentId
          AND w.state = 'fired' AND w.consumer = 'prompt'
          AND w.origin = 'process:tightbeam' AND w.reresolve = 'lineage'
      )
      BEGIN
        SELECT RAISE(ABORT, 'fired supervision lineage sidecar is required');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_fired_lineage_sidecar_identity_immutable",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_fired_lineage_sidecar_identity_immutable
      BEFORE UPDATE OF wakeId, assignmentId, controllerOrigin, wakeKind, controllerState,
                       chargedGeneration, rootTurnSeq
      ON supervision_liveness_sidecar
      WHEN EXISTS (
        SELECT 1 FROM wakes w
        WHERE w.wakeId = OLD.wakeId AND w.assignmentId = OLD.assignmentId
          AND w.state = 'fired' AND w.consumer = 'prompt'
          AND w.origin = 'process:tightbeam' AND w.reresolve = 'lineage'
      )
      BEGIN
        SELECT RAISE(ABORT, 'fired supervision lineage sidecar identity is immutable');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_fired_lineage_turn_immutable_update",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_fired_lineage_turn_immutable_update
      BEFORE UPDATE OF seq, sessionKey, wakeId, assignmentId ON turns
      WHEN EXISTS (
        SELECT 1 FROM wakes w
        WHERE w.wakeId = OLD.wakeId AND w.assignmentId = OLD.assignmentId
          AND w.state = 'fired' AND w.consumer = 'prompt'
          AND w.origin = 'process:tightbeam' AND w.reresolve = 'lineage'
      )
        AND (
          NEW.seq IS NOT OLD.seq OR NEW.sessionKey IS NOT OLD.sessionKey
          OR NEW.wakeId IS NOT OLD.wakeId OR NEW.assignmentId IS NOT OLD.assignmentId
        )
      BEGIN
        SELECT RAISE(ABORT, 'fired supervision lineage turn attribution is immutable');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_fired_lineage_turn_immutable_delete",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_fired_lineage_turn_immutable_delete
      BEFORE DELETE ON turns
      WHEN EXISTS (
        SELECT 1 FROM wakes w
        WHERE w.wakeId = OLD.wakeId AND w.assignmentId = OLD.assignmentId
          AND w.state = 'fired' AND w.consumer = 'prompt'
          AND w.origin = 'process:tightbeam' AND w.reresolve = 'lineage'
      )
      BEGIN
        SELECT RAISE(ABORT, 'fired supervision lineage turn is required');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_controller_root_immutable_update",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_controller_root_immutable_update
      BEFORE UPDATE OF wakeId, assignmentId, controllerOrigin, wakeKind, rootTurnSeq
      ON supervision_liveness_sidecar
      WHEN OLD.controllerOrigin IS NOT NULL
        AND (
          NEW.wakeId IS NOT OLD.wakeId OR NEW.assignmentId IS NOT OLD.assignmentId
          OR NEW.controllerOrigin IS NOT OLD.controllerOrigin
          OR NEW.wakeKind IS NOT OLD.wakeKind
          OR NEW.rootTurnSeq IS NOT OLD.rootTurnSeq
        )
      BEGIN
        SELECT RAISE(ABORT, 'supervision controller root link is immutable');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_controller_root_immutable_delete",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_controller_root_immutable_delete
      BEFORE DELETE ON supervision_liveness_sidecar
      WHEN OLD.controllerOrigin IS NOT NULL
      BEGIN
        SELECT RAISE(ABORT, 'supervision controller root link is required');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_controller_wake_identity_immutable",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_controller_wake_identity_immutable
      BEFORE UPDATE OF wakeId, sessionKey, assignmentId ON wakes
      WHEN EXISTS (
        SELECT 1 FROM supervision_liveness_sidecar s
        WHERE s.wakeId=OLD.wakeId AND s.assignmentId=OLD.assignmentId
          AND s.controllerOrigin IS NOT NULL
      )
        AND (
          NEW.wakeId IS NOT OLD.wakeId OR NEW.sessionKey IS NOT OLD.sessionKey
          OR NEW.assignmentId IS NOT OLD.assignmentId
        )
      BEGIN
        SELECT RAISE(ABORT, 'supervision controller wake identity is immutable');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_controller_wake_immutable_delete",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_controller_wake_immutable_delete
      BEFORE DELETE ON wakes
      WHEN EXISTS (
        SELECT 1 FROM supervision_liveness_sidecar s
        WHERE s.wakeId=OLD.wakeId AND s.assignmentId=OLD.assignmentId
          AND s.controllerOrigin IS NOT NULL
      )
      BEGIN
        SELECT RAISE(ABORT, 'supervision controller wake is required');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_controller_root_turn_immutable_update",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_controller_root_turn_immutable_update
      BEFORE UPDATE OF seq, assignmentId ON turns
      WHEN EXISTS (
        SELECT 1 FROM supervision_liveness_sidecar s
        WHERE s.rootTurnSeq=OLD.seq AND s.assignmentId=OLD.assignmentId
      )
        AND (NEW.seq IS NOT OLD.seq OR NEW.assignmentId IS NOT OLD.assignmentId)
      BEGIN
        SELECT RAISE(ABORT, 'supervision controller root turn identity is immutable');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_controller_root_turn_immutable_delete",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_controller_root_turn_immutable_delete
      BEFORE DELETE ON turns
      WHEN EXISTS (
        SELECT 1 FROM supervision_liveness_sidecar s
        WHERE s.rootTurnSeq=OLD.seq AND s.assignmentId=OLD.assignmentId
      )
      BEGIN
        SELECT RAISE(ABORT, 'supervision controller root turn is required');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_controller_turn_identity_immutable_update",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_controller_turn_identity_immutable_update
      BEFORE UPDATE OF seq, sessionKey, wakeId, assignmentId ON turns
      WHEN EXISTS (
        SELECT 1
        FROM supervision_liveness_sidecar s
        JOIN wakes w ON w.wakeId=s.wakeId AND w.assignmentId=s.assignmentId
        WHERE s.controllerOrigin IS NOT NULL
          AND OLD.wakeId=w.wakeId AND OLD.assignmentId=w.assignmentId
          AND OLD.sessionKey=w.sessionKey
      )
        AND (
          NEW.seq IS NOT OLD.seq OR NEW.sessionKey IS NOT OLD.sessionKey
          OR NEW.wakeId IS NOT OLD.wakeId OR NEW.assignmentId IS NOT OLD.assignmentId
        )
      BEGIN
        SELECT RAISE(ABORT, 'supervision controller turn identity is immutable');
      END
      """
    },
    %{
      type: "trigger",
      name: "supervision_controller_turn_immutable_delete",
      sql: """
      CREATE TRIGGER IF NOT EXISTS supervision_controller_turn_immutable_delete
      BEFORE DELETE ON turns
      WHEN EXISTS (
        SELECT 1
        FROM supervision_liveness_sidecar s
        JOIN wakes w ON w.wakeId=s.wakeId AND w.assignmentId=s.assignmentId
        WHERE s.controllerOrigin IS NOT NULL
          AND OLD.wakeId=w.wakeId AND OLD.assignmentId=w.assignmentId
          AND OLD.sessionKey=w.sessionKey
      )
      BEGIN
        SELECT RAISE(ABORT, 'supervision controller turn is required');
      END
      """
    }
  ]

  defmodule ShapeError do
    @moduledoc "A database whose shape this build cannot read. Never repaired in place."
    defexception [:message]
  end

  @doc """
  Create every production schema in dependency-safe order.

  Refuses a database this build cannot read. Every `ensure_schema/1` below is
  `CREATE TABLE IF NOT EXISTS`, which is silent about a table that already
  exists in an OLDER shape: it adds no column, so the first query naming one
  dies as an accidental `no such column`, and a column added by hand would be
  worse — `sessions.model` from before the structured identity holds packed
  values like `claude-fable-5[1m]`, which this build would read as a FAMILY.
  A wrong answer, from data that was right when it was written.

  So the shape is STAMPED at creation and CHECKED here, per the house rule: a
  missing or unknown stamp is a refusal and a bug report, never an inference.
  Note the direction — the one existence question below is asked to REFUSE,
  never to deduce a shape and accommodate it. The sole accepted predecessor is
  named by the exact migration stamps below; each upgrade is transactional.
  No shape is inferred from stored DDL.
  """
  @spec ensure_all(DB.server()) :: :ok
  def ensure_all(db) do
    :ok = ensure_stamp_table(db)
    :ok = check_shape(db)

    Enum.each(@schema_modules, fn module ->
      :ok = module.ensure_schema(db)
    end)

    :ok = Tightbeam.Escalation.ensure_terminal_epoch(db)

    :ok = Tightbeam.ColdStart.validate!(db)

    activated_at = System.system_time(:millisecond)

    case DB.transaction(db, fn txn ->
           ensure_supervision_liveness_v1_in_txn(txn, activated_at)
         end) do
      {:ok, :ok} ->
        :ok

      {:error, %ShapeError{} = error} ->
        raise error

      {:error, error} ->
        raise ShapeError,
          message:
            "incompatible_supervision_liveness_v1: additive activation failed: #{Exception.message(error)}"
    end
  end

  @doc false
  @spec upgrade_operational_parent_v1(DB.server(), keyword()) :: :ok
  def upgrade_operational_parent_v1(db, opts \\ []) when is_list(opts) do
    case DB.foreign_key_rebuild(db, fn txn ->
           case Txn.q(txn, "SELECT shape FROM schema_stamp") do
             [[@operational_parent_previous_shape]] ->
               :ok

             rows ->
               raise ShapeError,
                 message: "incompatible_operational_parent_v1: predecessor stamp #{inspect(rows)}"
           end

           :ok = Tightbeam.Org.migrate_operational_parent_v1_in_txn(txn, opts)

           Txn.q(
             txn,
             "UPDATE schema_stamp SET shape=?2, stampedAt=?3 WHERE shape=?1",
             [
               @operational_parent_previous_shape,
               @operational_parent_shape,
               System.system_time(:millisecond)
             ]
           )

           if Txn.changes(txn) != 1 do
             raise ShapeError, message: "incompatible_operational_parent_v1: stamp race"
           end

           :ok
         end) do
      {:ok, :ok} ->
        :ok

      {:error, %ShapeError{} = error} ->
        raise error

      {:error, error} ->
        raise ShapeError,
          message:
            "incompatible_operational_parent_v1: upgrade failed: #{Exception.message(error)}"
    end
  end

  @doc false
  @spec upgrade_message_type_v1(DB.server()) :: :ok
  def upgrade_message_type_v1(db) do
    migration_time = System.system_time(:millisecond)

    case DB.transaction(db, fn txn ->
           case Txn.q(txn, "SELECT shape FROM schema_stamp") do
             [[@message_type_previous_shape]] ->
               :ok

             rows ->
               raise ShapeError,
                 message: "incompatible_message_type_v1: predecessor stamp #{inspect(rows)}"
           end

           :ok = Txn.exec(txn, "ALTER TABLE messages ADD COLUMN messageType TEXT")

           Txn.q(
             txn,
             "UPDATE schema_stamp SET shape=?2, stampedAt=?3 WHERE shape=?1",
             [@message_type_previous_shape, @terminal_decision_previous_shape, migration_time]
           )

           if Txn.changes(txn) != 1 do
             raise ShapeError, message: "incompatible_message_type_v1: stamp race"
           end

           :ok
         end) do
      {:ok, :ok} ->
        :ok

      {:error, %ShapeError{} = error} ->
        raise error

      {:error, error} ->
        raise ShapeError,
          message: "incompatible_message_type_v1: upgrade failed: #{Exception.message(error)}"
    end
  end

  @doc false
  @spec upgrade_terminal_operator_decision_v1(DB.server()) :: :ok
  def upgrade_terminal_operator_decision_v1(db) do
    migration_time = System.system_time(:millisecond)

    case DB.foreign_key_rebuild(db, fn txn ->
           case Txn.q(txn, "SELECT shape FROM schema_stamp") do
             [[@terminal_decision_previous_shape]] ->
               :ok

             rows ->
               raise ShapeError,
                 message:
                   "incompatible_terminal_operator_decision_v1: predecessor stamp #{inspect(rows)}"
           end

           :ok = Tightbeam.Escalation.migrate_terminal_operator_decision_v1_in_txn(txn)

           Txn.q(
             txn,
             "UPDATE schema_stamp SET shape=?2, stampedAt=?3 WHERE shape=?1",
             [
               @terminal_decision_previous_shape,
               @nullable_effective_parent_previous_shape,
               migration_time
             ]
           )

           if Txn.changes(txn) != 1 do
             raise ShapeError,
               message: "incompatible_terminal_operator_decision_v1: stamp race"
           end

           :ok
         end) do
      {:ok, :ok} ->
        :ok

      {:error, %ShapeError{} = error} ->
        raise error

      {:error, error} ->
        raise ShapeError,
          message:
            "incompatible_terminal_operator_decision_v1: upgrade failed: #{Exception.message(error)}"
    end
  end

  @doc false
  @spec upgrade_cold_start_v1(DB.server(), keyword()) :: :ok
  def upgrade_cold_start_v1(db, opts \\ []) when is_list(opts) do
    migration_time = System.system_time(:millisecond)

    case DB.foreign_key_rebuild(db, fn txn ->
           case Txn.q(txn, "SELECT shape FROM schema_stamp") do
             [[@cold_start_previous_shape]] ->
               :ok

             rows ->
               incompatible_cold_start!("legacy_witness_missing", "predecessor #{inspect(rows)}")
           end

           ensure_no_migration_objects!(txn)

           :ok =
             Txn.exec(
               txn,
               """
               CREATE TABLE users_cold_start_v1 (
                 userId       TEXT PRIMARY KEY,
                 isAdmin      INTEGER NOT NULL DEFAULT 0,
                 creationKind TEXT NOT NULL DEFAULT 'legacy' CHECK (creationKind IN (
                   'cold_start','gateway_local_bootstrap','device_pair','admin_add','legacy'
                 )),
                 createdAt    INTEGER NOT NULL
               )
               """
             )

           Txn.q(
             txn,
             """
             INSERT INTO users_cold_start_v1 (userId,isAdmin,creationKind,createdAt)
             SELECT userId,isAdmin,'legacy',createdAt FROM users ORDER BY createdAt,userId
             """
           )

           maybe_interrupt_cold_start_migration!(opts, :after_copy)
           :ok = Txn.exec(txn, "DROP TABLE users")
           maybe_interrupt_cold_start_migration!(opts, :after_drop)
           :ok = Txn.exec(txn, "ALTER TABLE users_cold_start_v1 RENAME TO users")

           :ok = Txn.exec(txn, Tightbeam.ColdStart.receipt_ddl())

           :ok =
             Txn.exec(
               txn,
               """
               CREATE TRIGGER users_gateway_owned_insert
               BEFORE INSERT ON users
               WHEN NEW.creationKind = 'legacy'
               BEGIN
                 SELECT RAISE(ABORT, 'bootstrap_owned_by_gateway');
               END
               """
             )

           maybe_interrupt_cold_start_migration!(opts, :after_schema)

           case Txn.q(txn, "SELECT COUNT(*) FROM users") do
             [[0]] ->
               :ok

             [[_count]] ->
               case legacy_witness(txn) do
                 nil ->
                   incompatible_cold_start!("legacy_witness_missing")

                 %{user_id: user_id, device_id: device_id, root: root} ->
                   Txn.q(
                     txn,
                     """
                     INSERT INTO cold_start_receipts
                       (id,userId,deviceId,rootSessionKey,cause,phase,principal,
                        requestFingerprint,replaySecretHash,claimTokenHash,claimEventId,
                        deviceEventId,createdAt,activatedAt)
                     VALUES (1,?1,?2,?3,'v5_observed','complete','process:tightbeam',
                             NULL,NULL,NULL,NULL,NULL,?4,?4)
                     """,
                     [user_id, device_id, root, migration_time]
                   )
               end
           end

           maybe_interrupt_cold_start_migration!(opts, :after_receipt)

           Txn.q(
             txn,
             "UPDATE schema_stamp SET shape=?2, stampedAt=?3 WHERE shape=?1",
             [@cold_start_previous_shape, @message_type_previous_shape, migration_time]
           )

           if Txn.changes(txn) != 1, do: raise("cold-start stamp race")
           maybe_interrupt_cold_start_migration!(opts, :after_stamp)

           case Txn.q(txn, "PRAGMA foreign_key_check") do
             [] -> :ok
             rows -> incompatible_cold_start!("orphan_identity_row", inspect(rows))
           end

           case Tightbeam.ColdStart.classify_in_txn(txn) do
             %{state: state} when state in ["open", "claimed"] -> :ok
             %{invariant: invariant} -> incompatible_cold_start!(invariant)
           end
         end) do
      {:ok, :ok} ->
        :ok

      {:error, %ShapeError{} = error} ->
        raise error

      {:error, error} ->
        _ = error

        raise ShapeError,
          message:
            "incompatible_cold_start_v1: legacy_witness_missing; recovery: Recover an unusable fresh database"
    end
  end

  defp legacy_witness(txn) do
    Txn.q(
      txn,
      """
      SELECT d.deviceId,d.userId,s.sessionKey
      FROM devices d
      JOIN users u ON u.userId=d.userId
      JOIN sessions s ON s.ownerUserId=u.userId
      WHERE d.status='allowlisted' AND d.token IS NOT NULL AND u.isAdmin=1
        AND s.state='active' AND s.isBuiltIn=1 AND s.kind='main'
        AND s.operationalParent=s.sessionKey
      ORDER BY d.createdAt,d.deviceId,s.createdAt,s.sessionKey
      """
    )
    |> Enum.find_value(fn [device_id, user_id, root] ->
      if root == Tightbeam.Org.personal_session_key(user_id),
        do: %{device_id: device_id, user_id: user_id, root: root}
    end)
  end

  defp ensure_no_migration_objects!(txn) do
    case Txn.q(
           txn,
           "SELECT name FROM sqlite_master WHERE name IN ('users_cold_start_v1','cold_start_receipts','users_gateway_owned_insert')"
         ) do
      [] ->
        :ok

      rows ->
        incompatible_cold_start!("legacy_witness_missing", "migration objects #{inspect(rows)}")
    end
  end

  defp maybe_interrupt_cold_start_migration!(opts, point) do
    if Keyword.get(opts, :fail_at) == point, do: raise("forced cold-start migration interruption")
    :ok
  end

  defp incompatible_cold_start!(invariant, detail \\ nil) do
    _ = detail

    raise ShapeError,
      message:
        "incompatible_cold_start_v1: #{invariant}; recovery: Recover an unusable fresh database"
  end

  @doc false
  @spec upgrade_nullable_effective_parent_v1(DB.server(), keyword()) :: :ok
  def upgrade_nullable_effective_parent_v1(db, opts \\ []) when is_list(opts) do
    case DB.foreign_key_rebuild(db, fn txn ->
           case Txn.q(txn, "SELECT shape FROM schema_stamp") do
             [[@nullable_effective_parent_previous_shape]] ->
               :ok

             rows ->
               raise ShapeError,
                 message:
                   "incompatible_nullable_effective_parent_v1: predecessor stamp #{inspect(rows)}"
           end

           :ok = migrate_controller_root_link_in_txn(txn, opts)
           maybe_interrupt_nullable_effective_parent_migration!(opts, :after_root_link)

           :ok = Tightbeam.Org.migrate_nullable_effective_parent_in_txn(txn, opts)
           maybe_interrupt_nullable_effective_parent_migration!(opts, :after_migration)

           Txn.q(txn, "UPDATE schema_stamp SET shape=?2, stampedAt=?3 WHERE shape=?1", [
             @nullable_effective_parent_previous_shape,
             @shape,
             System.system_time(:millisecond)
           ])

           if Txn.changes(txn) != 1,
             do:
               raise(ShapeError, message: "incompatible_nullable_effective_parent_v1: stamp race")

           maybe_interrupt_nullable_effective_parent_migration!(opts, :after_stamp)

           case Txn.q(txn, "PRAGMA foreign_key_check") do
             [] ->
               :ok

             rows ->
               raise ShapeError,
                 message:
                   "incompatible_nullable_effective_parent_v1: foreign key check #{inspect(rows)}"
           end
         end) do
      {:ok, :ok} ->
        :ok

      {:error, %ShapeError{} = error} ->
        raise error

      {:error, error} ->
        raise ShapeError,
          message:
            "incompatible_nullable_effective_parent_v1: upgrade failed: #{Exception.message(error)}"
    end
  end

  defp maybe_interrupt_nullable_effective_parent_migration!(opts, point) do
    if Keyword.get(opts, :fail_at) == point,
      do: raise("forced nullable-effective-parent migration interruption")

    :ok
  end

  defp migrate_controller_root_link_in_txn(txn, opts) do
    predecessor_columns =
      Txn.q(txn, "PRAGMA table_info(supervision_liveness_sidecar)")
      |> Enum.map(fn [_cid, name | _rest] -> name end)

    if "rootTurnSeq" in predecessor_columns do
      raise ShapeError,
        message: "incompatible_nullable_effective_parent_v1: predecessor already has rootTurnSeq"
    end

    copied_columns = [
      "wakeId",
      "assignmentId",
      "controllerOrigin",
      "wakeKind",
      "controllerState",
      "chargedGeneration",
      "transferEvidenceId",
      "retirementEpoch",
      "retiringSessionKey",
      "retirementOutcomeKind",
      "retirementOutcomeId",
      "retirementTargetSessionKey",
      "retirementCause",
      "retirementPrincipal",
      "retirementActionNeeded"
    ]

    column_list = Enum.join(copied_columns, ", ")

    :ok =
      Txn.exec(
        txn,
        "CREATE TEMP TABLE nullable_effective_parent_sidecar_v1 AS SELECT #{column_list} FROM supervision_liveness_sidecar"
      )

    maybe_interrupt_nullable_effective_parent_migration!(opts, :after_root_copy)

    dependent_objects =
      (@supervision_liveness_objects ++ @supervision_liveness_enforcement_objects)
      |> Enum.filter(fn object ->
        object.name != "supervision_liveness_sidecar" and
          String.contains?(object.sql, "supervision_liveness_sidecar")
      end)

    Enum.each(dependent_objects, fn object ->
      :ok = Txn.exec(txn, "DROP #{String.upcase(object.type)} IF EXISTS #{object.name}")
    end)

    :ok = Txn.exec(txn, "DROP TABLE supervision_liveness_sidecar")
    maybe_interrupt_nullable_effective_parent_migration!(opts, :after_root_drop)

    sidecar =
      Enum.find(@supervision_liveness_objects, fn object ->
        object.name == "supervision_liveness_sidecar"
      end)

    :ok = Txn.exec(txn, sidecar.sql)

    Txn.q(
      txn,
      "INSERT INTO supervision_liveness_sidecar (#{column_list}) SELECT #{column_list} FROM nullable_effective_parent_sidecar_v1"
    )

    :ok = Txn.exec(txn, "DROP TABLE nullable_effective_parent_sidecar_v1")

    Enum.each(dependent_objects, fn object ->
      :ok = Txn.exec(txn, object.sql)
      validate_owned_object!(txn, object)
    end)

    validate_owned_object!(txn, sidecar)
    maybe_interrupt_nullable_effective_parent_migration!(opts, :after_root_restore)
    :ok
  end

  @doc false
  @spec ensure_supervision_liveness_v1_in_txn(Txn.t()) :: :ok
  def ensure_supervision_liveness_v1_in_txn(%Txn{} = txn) do
    ensure_supervision_liveness_v1_in_txn(txn, System.system_time(:millisecond))
  end

  @doc false
  @spec ensure_supervision_liveness_v1_in_txn(Txn.t(), non_neg_integer()) :: :ok
  def ensure_supervision_liveness_v1_in_txn(%Txn{} = txn, activated_at) do
    ensure_supervision_liveness_v1_in_txn(txn, activated_at, [])
  end

  @doc false
  @spec ensure_supervision_liveness_v1_in_txn(Txn.t(), non_neg_integer(), keyword()) :: :ok
  def ensure_supervision_liveness_v1_in_txn(%Txn{} = txn, activated_at, opts)
      when is_integer(activated_at) and activated_at >= 0 and is_list(opts) do
    present = Enum.filter(@supervision_liveness_objects, &owned_object_present?(txn, &1))
    Enum.each(present, &validate_owned_object!(txn, &1))

    case length(present) do
      0 ->
        @supervision_liveness_objects
        |> Enum.with_index(1)
        |> Enum.each(fn {object, index} ->
          :ok = Txn.exec(txn, object.sql)
          validate_owned_object!(txn, object)
          maybe_interrupt_activation!(opts, index)
        end)

        Txn.q(
          txn,
          """
          INSERT INTO supervision_liveness_epoch
            (id, activatedAt, cause, principal)
          VALUES (0, ?1, 'schema_activation', 'process:tightbeam')
          """,
          [activated_at]
        )

        maybe_interrupt_activation!(opts, length(@supervision_liveness_objects) + 1)

      count when count == length(@supervision_liveness_objects) ->
        :ok

      _count ->
        missing =
          @supervision_liveness_objects
          |> Kernel.--(present)
          |> Enum.map_join(", ", & &1.name)

        incompatible_supervision_liveness!("incomplete additive shape; missing #{missing}")
    end

    validate_activation_epoch!(txn)

    Enum.each(@supervision_liveness_enforcement_objects, fn object ->
      if owned_object_present?(txn, object) do
        validate_owned_object!(txn, object)
      else
        :ok = Txn.exec(txn, object.sql)
        validate_owned_object!(txn, object)
      end
    end)

    :ok
  end

  def ensure_supervision_liveness_v1_in_txn(%Txn{}, _activated_at, _opts) do
    incompatible_supervision_liveness!("activation epoch must be a nonnegative integer")
  end

  defp owned_object_present?(txn, %{type: type, name: name}) do
    case Txn.q(
           txn,
           "SELECT 1 FROM sqlite_master WHERE type = ?1 AND name = ?2",
           [type, name]
         ) do
      [] -> false
      [[1]] -> true
      _rows -> incompatible_supervision_liveness!("duplicate owned object #{name}")
    end
  end

  defp validate_owned_object!(txn, %{type: type, name: name, sql: expected_sql}) do
    case Txn.q(
           txn,
           "SELECT sql FROM sqlite_master WHERE type = ?1 AND name = ?2",
           [type, name]
         ) do
      [[actual_sql]] when is_binary(actual_sql) ->
        if normalize_schema_sql(actual_sql) == normalize_schema_sql(expected_sql) do
          :ok
        else
          incompatible_supervision_liveness!("malformed owned object #{name}")
        end

      [] ->
        incompatible_supervision_liveness!("missing owned object #{name}")

      _rows ->
        incompatible_supervision_liveness!("duplicate owned object #{name}")
    end
  end

  defp normalize_schema_sql(sql) do
    sql
    |> String.downcase()
    |> String.replace(~r/\bif\s+not\s+exists\b/u, "")
    |> String.replace(~r/\s+/u, "")
    |> String.trim_trailing(";")
  end

  defp maybe_interrupt_activation!(opts, statement_index) do
    if Keyword.get(opts, :fail_after_statement) == statement_index do
      raise "forced activation interruption"
    end

    :ok
  end

  defp validate_activation_epoch!(txn) do
    case Txn.q(
           txn,
           "SELECT id, activatedAt, cause, principal FROM supervision_liveness_epoch ORDER BY id"
         ) do
      [[0, activated_at, "schema_activation", "process:tightbeam"]]
      when is_integer(activated_at) and activated_at >= 0 ->
        :ok

      _rows ->
        incompatible_supervision_liveness!("malformed supervision_liveness_epoch row")
    end
  end

  defp incompatible_supervision_liveness!(detail) do
    raise ShapeError, message: "incompatible_supervision_liveness_v1: #{detail}"
  end

  defp ensure_stamp_table(db) do
    DB.execute(db, """
    CREATE TABLE IF NOT EXISTS schema_stamp (
      shape     TEXT PRIMARY KEY,
      stampedAt INTEGER NOT NULL
    );
    """)
  end

  defp check_shape(db) do
    case DB.query(db, "SELECT shape FROM schema_stamp") do
      {:ok, [[@shape]]} ->
        :ok

      {:ok, [[@nullable_effective_parent_previous_shape]]} ->
        upgrade_nullable_effective_parent_v1(db)

      {:ok, [[@terminal_decision_previous_shape]]} ->
        :ok = upgrade_terminal_operator_decision_v1(db)
        upgrade_nullable_effective_parent_v1(db)

      {:ok, [[@message_type_previous_shape]]} ->
        :ok = upgrade_message_type_v1(db)
        :ok = upgrade_terminal_operator_decision_v1(db)
        upgrade_nullable_effective_parent_v1(db)

      {:ok, [[@cold_start_previous_shape]]} ->
        :ok = upgrade_cold_start_v1(db)
        :ok = upgrade_message_type_v1(db)
        :ok = upgrade_terminal_operator_decision_v1(db)
        upgrade_nullable_effective_parent_v1(db)

      {:ok, [[@operational_parent_previous_shape]]} ->
        :ok = upgrade_operational_parent_v1(db)
        :ok = upgrade_cold_start_v1(db)
        :ok = upgrade_message_type_v1(db)
        :ok = upgrade_terminal_operator_decision_v1(db)
        upgrade_nullable_effective_parent_v1(db)

      {:ok, []} ->
        # No stamp. Either a database this build is about to create, or one
        # written before stamping existed. Those are DIFFERENT, and telling
        # them apart is the whole point — an unstamped database with a
        # `sessions` table in it predates the structured model identity.
        unstamped(db)

      {:ok, [[found]]} ->
        raise ShapeError, """
        this Tightbeam database was written by a different build.

          stamped: #{found}
          this build: #{@shape}

        There is no migration from #{found}. The only supported upgrade sources
        are #{@operational_parent_previous_shape}, #{@cold_start_previous_shape},
        #{@message_type_previous_shape}, #{@terminal_decision_previous_shape}, and
        #{@nullable_effective_parent_previous_shape}.
        Move this database aside and let it be recreated.
        """

      # More than one shape stamped. Nothing writes a second row, so this is a
      # database in a state this build has no reading for — which is a refusal
      # like any other, not an unhandled case falling out as a CaseClauseError.
      {:ok, [_ | _] = rows} ->
        raise ShapeError, """
        this Tightbeam database carries MORE THAN ONE shape stamp.

          stamped: #{rows |> List.flatten() |> Enum.join(", ")}
          this build: #{@shape}

        Nothing in Tightbeam writes a second stamp, so this database was
        assembled by something else. Move it aside and let it be recreated.
        """
    end
  end

  # A FRESH DATABASE MUST NEVER BE REFUSED, which is why the stamp is written
  # HERE — before a single table exists — rather than after the modules run.
  # Stamped last, a bootstrap interrupted between `sessions` and the stamp left
  # an unstamped database WITH sessions, indistinguishable from a genuinely old
  # one, and the next boot refused a database this build had just created. The
  # absence class again: "interrupted fresh bootstrap" and "genuine old
  # database" sharing one representation.
  #
  # Stamping first cannot lose that way. Interrupted after the stamp, the next
  # boot reads its own shape and carries on creating what is missing, which is
  # exactly what `CREATE TABLE IF NOT EXISTS` is for.
  defp unstamped(db) do
    case DB.query(db, "SELECT name FROM sqlite_master WHERE type='table' AND name='sessions'") do
      {:ok, []} ->
        stamp(db)

      {:ok, [_ | _]} ->
        raise ShapeError, """
        this Tightbeam database predates the structured model identity (#{@shape}).

        Its `sessions` table carries no shape stamp, so its `model` column holds
        PACKED identifiers — `claude-fable-5[1m]` meaning a 1M-context model —
        and `thinkingLevel`/`modelContext` were never written. This build reads
        those three columns as separate fields, so it would take the whole
        packed string as the model's family and silently run the wrong model.

        There is no migration and nothing here will repair it. Move the database
        aside and let it be recreated.
        """
    end
  end

  defp stamp(db) do
    {:ok, _} =
      DB.query(
        db,
        "INSERT OR IGNORE INTO schema_stamp (shape, stampedAt) VALUES (?1, ?2)",
        [@shape, System.system_time(:millisecond)]
      )

    :ok
  end
end
